#include "pico/stdlib.h"
#include "pico/multicore.h"

// .----------------------------------------------------------.
// | Core 1 code                                              |
// `----------------------------------------------------------'

uint32_t this_count = 0;

#define LED 25

void core1_code(void) {
    gpio_init(LED);
    gpio_set_dir(LED, GPIO_OUT);
    while (true) {
        sleep_ms(500); gpio_put(LED, 1);
        sleep_ms(500); gpio_put(LED, 0);
        this_count++;
    }
}

// .----------------------------------------------------------.
// | Core 1 launcher                                          |
// `----------------------------------------------------------'

void core1_init(void) {
    multicore_launch_core1(core1_code);
}

// .----------------------------------------------------------.
// | Core 1 tick detector                                     |
// `----------------------------------------------------------'

uint32_t last_count = 0;

bool core1_tick(void) {
   if (this_count == last_count) {
       return false;
   } else {
       last_count = this_count;
       return true;
   }
}
