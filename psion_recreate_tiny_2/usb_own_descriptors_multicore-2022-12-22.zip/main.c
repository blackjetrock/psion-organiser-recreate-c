#include <stdio.h>
#include "pico/stdlib.h"
#include "bsp/board.h"
#include "tusb.h"

extern void core1_init(void);
extern bool core1_tick(void);

extern void own_task(void);

int main(void) {
    board_init();
    tusb_init();
    core1_init();
    stdio_init_all();
    while(true) {
        if (core1_tick()) {
            printf("~/mypico/usb_own_desriptors_loop/multicore.c\n");
        }
        tud_task();
        own_task();
        sleep_ms(1);
    }
}
